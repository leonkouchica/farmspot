import React from 'react'
import { Link } from 'react-router-dom'

const About = () => {
  return (
    <section className="contact py-80">
        <div className="container container-lg">
            <div className="row gy-5">
                <h1>About FarmSpot</h1>
            </div>
        </div>
    </section>
  )
}

export default About